begin
   execute immediate 'drop table policy';
exception
   when others then null;
end;
/

create table policy(
	policy_id varchar2(30),
	customer varchar2(40),
	policy_value binary_double,
	policy_plan varchar2(40),
	status varchar2(20),
	coverage_percentage binary_double);

insert into policy values('PCICAJOH1','John',80000,'Home','Active',80);
insert into policy values('PCICASAR5','Sara',70000,'Vehicle','Active',74.5);
insert into policy values('PCICAAND6','Andrew',50000,'Vehicle','Closed',72);
insert into policy values('PCICABEN8','Benita',100000,'Villa','Closed',73);