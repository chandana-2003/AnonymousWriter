package com.spring.dao;

import com.spring.entity.*;
import java.sql.ResultSet;
import java.sql.Types;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component("policyDAO")
public class PolicyDAO {
    
	private DataSource datasource;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    public DataSource getDataSource() {
		return datasource;
	}
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate= new JdbcTemplate(dataSource);
	}
    
	public List<Policy> getAllPolices() {
		//fill your code
		return null;        
    }
    
    public boolean deletePolicy(String policyId) {
        //fill your code
		return false;
        
    }
    
}