package com.spring.entity;

public class Policy {

	private String policyId;
	private String customer;
	private Double policyValue;
	private String policyPlan;
	private String status;
	private Double coveragePercentage;
	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Policy(String policyId, String customer, Double policyValue, String policyPlan, String status,
			Double coveragePercentage) {
		super();
		this.policyId = policyId;
		this.customer = customer;
		this.policyValue = policyValue;
		this.policyPlan = policyPlan;
		this.status = status;
		this.coveragePercentage = coveragePercentage;
	}
	public String getPolicyId() {
		return policyId;
	}
	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public Double getPolicyValue() {
		return policyValue;
	}
	public void setPolicyValue(Double policyValue) {
		this.policyValue = policyValue;
	}
	public String getPolicyPlan() {
		return policyPlan;
	}
	public void setPolicyPlan(String policyPlan) {
		this.policyPlan = policyPlan;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Double getCoveragePercentage() {
		return coveragePercentage;
	}
	public void setCoveragePercentage(Double coveragePercentage) {
		this.coveragePercentage = coveragePercentage;
	}

}
