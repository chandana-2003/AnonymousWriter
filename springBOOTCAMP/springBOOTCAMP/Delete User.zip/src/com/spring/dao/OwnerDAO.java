package com.spring.dao;

import com.spring.entity.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

public class OwnerDAO {
    
	
	public List<Owner> getAllOwners(){
		return null;
		
	}
	
	public String getOwnerById(int id) {
		
		
	}
	public void deleteOwner(int id){

	}
	
	

}
