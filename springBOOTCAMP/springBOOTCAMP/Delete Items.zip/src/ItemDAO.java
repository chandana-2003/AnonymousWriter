//FILL YOUR CODE
public class ItemDAO {
	public void delete(Item item) {
		//FILL YOUR CODE
	}

	public List<Item> list(){
		//FILL YOUR CODE
	}
	
	public Item find(int id){
		//FILL YOUR CODE
	}
}
